#include <iostream>
using namespace std;

class Employee {
public:
    int empNum;
    string name;
    double salary;

    Employee(int empNum, string name, double salary) {
        this->empNum = empNum;
        this->name = name;
        this->salary = salary;
    }
};

class Node {
public:
    Employee* emp;
    Node* left;
    Node* right;

    Node(Employee* emp) {
        this->emp = emp;
        left = NULL;
        right = NULL;
    }
};

class EmployeeBST {
private:
    Node* root;

    Node* insert(Node* node, Employee* emp) {
        if (node == NULL) {
            return new Node(emp);
        }

        if (emp->empNum < node->emp->empNum) {
            node->left = insert(node->left, emp);
        } else {
            node->right = insert(node->right, emp);
        }

        return node;
    }

    Node* search(Node* node, int empNum) {
        if (node == NULL || node->emp->empNum == empNum) {
            return node;
        }

        if (empNum < node->emp->empNum) {
            return search(node->left, empNum);
        }

        return search(node->right, empNum);
    }

    Node* findMin(Node* node) {
        while (node->left != NULL) {
            node = node->left;
        }
        return node;
    }

    Node* deleteNode(Node* root, int empNum) {
        if (root == NULL) {
            return root;
        }

        if (empNum < root->emp->empNum) {
            root->left = deleteNode(root->left, empNum);
        } else if (empNum > root->emp->empNum) {
            root->right = deleteNode(root->right, empNum);
        } else {
            if (root->left == NULL) {
                Node* temp = root->right;
                delete root;
                return temp;
            } else if (root->right == NULL) {
                Node* temp = root->left;
                delete root;
                return temp;
            }

            Node* temp = findMin(root->right);
            root->emp = temp->emp;
            root->right = deleteNode(root->right, temp->emp->empNum);
        }
        return root;
    }

    void preorder(Node* node) {
        if (node != NULL) {
            cout << "Employee Number: " << node->emp->empNum << ", Name: " << node->emp->name << ", Salary: " << node->emp->salary << endl;
            preorder(node->left);
            preorder(node->right);
        }
    }

public:
    EmployeeBST() {
        root = NULL;
    }

    void insert(Employee* emp) {
        root = insert(root, emp);
    }

    Employee* search(int empNum) {
        Node* result = search(root, empNum);
        if (result != NULL) {
            return result->emp;
        }
        return NULL;
    }

    void deleteEmployee(int empNum) {
        root = deleteNode(root, empNum);
    }

    void preorder() {
        preorder(root);
    }
};

int main() {
    EmployeeBST bst;

    Employee* emp1 = new Employee(1001, "Jungkook Jeon", 590000);
    Employee* emp2 = new Employee(1002, "Kim Seokjin", 620000);
    Employee* emp3 = new Employee(1003, "Park Jimin", 580000);

    bst.insert(emp1);
    bst.insert(emp2);
    bst.insert(emp3);

    cout << "Pre-order traversal of employees:" << endl;
    bst.preorder();

    cout << "Searching for employee with number 1002:" << endl;
    Employee* found = bst.search(1002);
    if (found != NULL) {
        cout << "Found: " << found->name << ", Salary: " << found->salary << endl;
    } else {
        cout << "Employee not found." << endl;
    }

    cout << "Deleting employee with number 1001:" << endl;
    bst.deleteEmployee(1001);

    cout << "Pre-order traversal after deletion:" << endl;
    bst.preorder();

    return 0;
}



